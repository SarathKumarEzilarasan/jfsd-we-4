package com.example.employment_service.service;

import com.example.employment_service.dto.ApiResponseDto;
import com.example.employment_service.dto.EmployeeDto;

public interface EmployeeService {
    EmployeeDto saveEmployee(EmployeeDto employeeDto);

    ApiResponseDto getEmployeeById(Long employeeId);
}
