package com.springboot.demo.springboot_demo;

import com.springboot.demo.springboot_demo.bean.Student;

public class Test {
    public static void main(String[] args) {
        Student student = new Student(1, "John", "Doe");
        System.out.println(student.getLastName());
        student.setId(100);
        new Student();
    }
}
