package com.springboot.demo.springboot_demo.controller;

import com.springboot.demo.springboot_demo.bean.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("student")
public class StudentController {

    List<Student> students = Arrays.asList(
            new Student(1, "John", "Doe"),
            new Student(2, "Peter", "Doe")
    );

    @GetMapping
    public ResponseEntity<Student> getStudent() {
        Student student = new Student(1, "John", "Doe");
        return ResponseEntity.ok()
                .body(student);
    }

    @GetMapping("/students")
    public ResponseEntity<List<Student>> getStudents() {
        return ResponseEntity.ok()
                .body(students);
    }

    @GetMapping("/studentPath/{id}")
    public ResponseEntity<Student> studentFromPathVariable(@PathVariable("id") int studentId) {
        List<Student> result = students.stream().filter(student -> student.getId() == studentId).toList();
        return ResponseEntity.ok()
                .body(result.get(0));
    }

    @GetMapping("/studentQuery")
    public ResponseEntity<Student> studentFromQueryParam(@RequestParam("id") int studentId) {
        List<Student> result = students.stream().filter(student -> student.getId() == studentId).toList();
        return ResponseEntity.ok()
                .body(result.get(0));
    }

    @PostMapping("/create")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        System.out.println(student.getId());
        System.out.println(student.getFirstName());
        System.out.println(student.getLastName());
        return new ResponseEntity<>(student, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable("id") int id) {
        System.out.println(student.getId());
        System.out.println(student.getFirstName());
        System.out.println(student.getLastName());
        System.out.println(id);
        return new ResponseEntity<>(student, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int id) {
        System.out.println(id);
        return new ResponseEntity<>("Student deleted successfully!!!", HttpStatus.NO_CONTENT);
    }
}
