package com.example.springboot_jpa_demo;

import com.example.springboot_jpa_demo.dto.UserDto;
import com.example.springboot_jpa_demo.entity.User;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@OpenAPIDefinition(
        info = @Info(
                title = "Spring Boot User Rest API Documentation",
                description = "Spring Boot User Rest API Documentation",
                version = "v1.0",
                contact = @Contact(
                        name = "John",
                        email = "test@gmail.com",
                        url = "https://www.google.com"
                ),
                license = @License(
                        name = "Apache 2.0",
                        url = "https://www.google.com"
                )
        )
)
public class SpringbootJpaDemoApplication {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.createTypeMap(UserDto.class, User.class)
                .addMapping(UserDto::getId, User::setId)
                .addMapping(UserDto::getFirstName, User::setFirstName);

        modelMapper.createTypeMap(User.class, UserDto.class)
                .addMapping(User::getId, UserDto::setId)
                .addMapping(User::getFirstName, UserDto::setFirstName);
        return modelMapper;
    }

    public static void main(String[] args) {
        SpringApplication.run(SpringbootJpaDemoApplication.class, args);
    }

}
