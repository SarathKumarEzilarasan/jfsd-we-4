package com.example.spring_batch;

public record Person(String firstName, String lastName) {
}
