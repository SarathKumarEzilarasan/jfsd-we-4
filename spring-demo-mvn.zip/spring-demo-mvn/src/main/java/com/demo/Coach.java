package com.demo;

public interface Coach {
    String getDailyWorkOut();

    String getDailyWish();
}
