package com.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MyApp {
    public static void main(String[] args) {

        AnnotationConfigApplicationContext context
                = new AnnotationConfigApplicationContext(SportsConfig.class);

        FootballCoach coach = context.getBean("footballCoach", FootballCoach.class);
        System.out.println(coach.getDailyWorkOut());
        System.out.println(coach.getDailyWish());
        System.out.println(coach.getEmailAddress());
        System.out.println(coach.getTeam());
        context.close();
    }
}

//bean scope -> singleton , prototype
//bean lifecycle -> after creation , before destroy