package com.demo;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class FootballCoach implements Coach {
    @Autowired
    private WishService wishService;
    @Value("${email}")
    private String emailAddress;
    @Value("${team}")
    private String team;

//    @Autowired
//    public void setWishService(WishService wishService) {
//        this.wishService = wishService;
//    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getDailyWorkOut() {
        return "Spend 30 mins kicking practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getWish();
    }

    @PostConstruct
    public void startupMethod() {
        System.out.println("started");
    }

    @PreDestroy
    public void destroyMethod() {
        System.out.println("destroyed");
    }
}
