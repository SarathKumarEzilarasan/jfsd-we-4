package com.demo;

public interface WishService {
    String getWish();
}
