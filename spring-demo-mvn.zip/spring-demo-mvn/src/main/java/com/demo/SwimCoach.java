package com.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class SwimCoach implements Coach {
    private WishService wishService;

    @Autowired
    public SwimCoach(WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut() {
        return "Spend 30 mins swimming practice";
    }

    @Override
    public String getDailyWish() {
        return wishService.getWish();
    }
}
