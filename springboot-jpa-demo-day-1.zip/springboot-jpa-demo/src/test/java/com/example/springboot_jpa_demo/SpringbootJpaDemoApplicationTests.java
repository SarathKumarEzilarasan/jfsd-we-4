package com.example.springboot_jpa_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
