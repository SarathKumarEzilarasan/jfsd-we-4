package com.example.springboot_jpa_demo.service;

import com.example.springboot_jpa_demo.entity.User;

public interface UserService {
   User createUser(User user);
}
