package com.example.frontend_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontendDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrontendDemoApplication.class, args);
	}

}
