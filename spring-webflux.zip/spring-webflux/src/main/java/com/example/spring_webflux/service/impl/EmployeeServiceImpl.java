package com.example.spring_webflux.service.impl;

import com.example.spring_webflux.dto.EmployeeDto;
import com.example.spring_webflux.entity.Employee;
import com.example.spring_webflux.repository.EmployeeRepository;
import com.example.spring_webflux.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private ModelMapper modelMapper;

    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        Mono<Employee> savedEmployee = employeeRepository.save(employee);
        return savedEmployee
                .map(entity -> modelMapper.map(entity, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> getEmployee(String employeeId) {
        Mono<Employee> employeeEntity = employeeRepository.findById(employeeId);
        return employeeEntity
                .map(entity -> modelMapper.map(entity, EmployeeDto.class));
    }

    @Override
    public Flux<EmployeeDto> getAllEmployees() {
        Flux<Employee> employeeFlux = employeeRepository.findAll();
        return employeeFlux
                .map(entity -> modelMapper.map(entity, EmployeeDto.class));
    }
}
